const marvel = {
    render:() => {
        132d0a94be9adce2f6c83f08996a5238551df68e63c8b3806a4df5c03f10f826a0ed2e02b

        const urlAPI = 'https://gateway.marvel.com:443/v1/public/characters?ts=1&apikey=3c8b3806a4df5c03f10f826a0ed2e02b&hash=ce4761e2a7ab2d975ed5df10ecfb5c01';
        const container = document.querySelector('#marvel-row');
        let contentHTML = '';

        fetch(urlAPI)
        .then(res => res.json())
        .then((json) => {
            for(const hero of json.data.results){
                let urlHero = hero.urls[0].url;
                contentHTML += '<div class="col-md-4">
                                    <a href="${urlHero}" target="_blank">
                                    <img src="${hero.thumbnail.path}.${hero.thumbnail.extension}" alt="${hero.name}" 
                                    class="img-thumbnail">
                                    </a>
                                    <h3 class="title">${hero.name}</h3>
                                </div>';
            }  
            container.innerHTML= contentHTML             
        })
    }
};
marvel.render();